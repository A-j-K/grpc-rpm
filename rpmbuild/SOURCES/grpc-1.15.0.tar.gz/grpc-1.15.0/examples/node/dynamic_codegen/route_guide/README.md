# gRPC Basics: Node.js sample code

The files in this folder are the samples used in [gRPC Basics: Node.js][], a detailed tutorial for using gRPC in Node.js.

[gRPC Basics: Node.js]:https://grpc.io/docs/tutorials/basic/node.html
